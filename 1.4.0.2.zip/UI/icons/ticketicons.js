const ticketIcons = {
    mainIcon: 'https://cdn.discordapp.com/emojis/1081651089339858954.gif', 
    correctIcon: 'https://cdn.discordapp.com/emojis/819446784647757834.gif', 
    correctrIcon : 'https://cdn.discordapp.com/attachments/1230824451990622299/1236802049190920202/4104-verify-red.gif?ex=66a5702b&is=66a41eab&hm=5f38fab7b9dab73a6250db1a5e149b94bcdd49b19d6b70e38253fa2b2470615f&',
    heartIcon: 'https://cdn.discordapp.com/attachments/1230824451990622299/1230824519220985896/6280-2.gif?ex=66a571e8&is=66a42068&hm=0761d49758b73e8bbe8785e7998acfd2f1f79b4f623f024072468d4420cc102e&',
    modIcon :'https://cdn.discordapp.com/emojis/805980519644004372.gif',
    pingIcon : 'https://cdn.discordapp.com/emojis/981302000694210620.gif',
};

module.exports = ticketIcons;