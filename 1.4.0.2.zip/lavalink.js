
module.exports = {
    enabled: true, 
    lavalink: {
      name: "GlaceYT",
      password: "glaceyt",
      host: "5.39.63.207",
      port:  8262,
      secure: false
    }
};
